
Developed By: Sammy Diamantstein: 101060342


Launching app:

To install npm modules execute:
>npm install
	This will install the modules listed as dependencies in the package.json file.

To run either execute:
>npm start
or 
>node server.js


To see the "app" version use your browser to visit:
> http://localhost:3000



Tested on:
- Mac OS with Chrome and Safari Browsers