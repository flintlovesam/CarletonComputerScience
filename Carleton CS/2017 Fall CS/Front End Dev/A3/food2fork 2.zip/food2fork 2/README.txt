***IMPORTANT: The code in this example will NOT run unless you add your openweathermap.org API ID Key to
the server.

To install npm modules execute:
>npm install

This will install the modules listed as dependencies in the package.json file.

To run either execute
>npm start
or 
>node server.js


To see the JSON object returned by the openweather.org API use your browser to visit:
http://localhost:3000/weather?city=Ottawa

To see the "app" version use your browser to visit:
http://localhost:3000