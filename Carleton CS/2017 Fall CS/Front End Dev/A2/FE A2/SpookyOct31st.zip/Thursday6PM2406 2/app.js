/*
Before you run this app first execute
>npm install
to load npm modules listed in package.json file

Then launch this server.
Then open several browsers to: http://localhost:3000/index.html

*/

var http = require('http');
//npm modules (need to install these first)
var WebSocketServer = require('ws').Server; //provides web sockets
var ecStatic = require('ecstatic');  //provides static file server service

//static file server
var server = http.createServer(ecStatic({root: __dirname + '/www'}));

var wss = new WebSocketServer({server: server});

var connections = {};
var connectionIDCounter = 0;


wss.on('connection', function(ws) {
  ws.id = connectionIDCounter ++;
  connections[ws.id] = ws;

  console.log('Client connected');

  ws.on('message', function(msg) {
    console.log('Message: ' + msg);
    //  broadcast(msg);
    if(Object.keys(JSON.parse(msg))[0] == "word")
    {
      console.log("hello");
      wss.clients.forEach(function(client) { // goes through each client sends message to them...will call this function to signal game over
        if(ws.id != client.id){
          client.send(msg);
        }
        if(ws.id == client.id){
          var playNum = { identit : client.id};
          client.send(JSON.stringify(playNum));
                }
      });
    }
  });

});

function broadcast(msg) {
  wss.clients.forEach(function(client) { // goes through each client sends message to them...will call this function to signal game over
    client.send(msg);
  });
}

server.listen(3000);
console.log('Server Running at http://127.0.0.1:3000  CNTL-C to quit');
