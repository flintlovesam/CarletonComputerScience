/*
example of simple module
*/
module.exports = function () {
    console.log('Port Wizard found server running at http://127.0.0.1:3000 CNTL-C to quit');
}
