Assignment 2: Word Matcher
Dave Nelson: 100988794
Sammy Diamantstein: 101060342


App Development 
- App was developed on a Mac computer, running node.js and testing code with Google Chrome web browser


App usage
- to play one round of the word matcher game, in terminal, run the command
$ node app.js

- then, once the server is running, please open up two chrome browsers to http://localhost:3000/assignment2.html
- play the game, as specified in the game guide. Once a game is done, please refresh the server, and refresh the browser windows to play again.

