Sam Diamantstein: 101060342
COMP 3000 Assignment 5:



STEPS TAKEN
Part 1

1. Write async.c, partly stemming from starter code provided by Prof. Michel Barbeau
2. Gcc -Wall async.c async
3. ./async

PART 2
1. Using starter code provided by Prof. Michel Barbeau in prime.c, duplicate relevant lines of code, and add one printf that takes the result1 and result2 and multiply them
2. In the a5 directory call “make”
3. ./prime


PROOF OF SUCCESS:

- SEE IMAGES titled Part 1 and Part 2
