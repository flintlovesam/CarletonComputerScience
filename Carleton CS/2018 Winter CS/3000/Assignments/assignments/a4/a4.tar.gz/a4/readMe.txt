Sam Diamantstein: 101060342
COMP 3000 Assignment 4:



STEPS TAKEN

1. Make directories:
  1) ~/mod
  2) ~/mod/pTest

2. Made my module titled sam_prime.c
  - located in ~/mod

3. Took the tester files provided in the assignment and placed them in the pTest directory

4. Added make file to the pTest file


TESTING CODE:
0. Unzip folder
1. cd mod
2. make
3. cd pTest
4. make
5. Cd ..
6. sudo insmod sam_prime.ko
7.ls -l /dev/sam_prime
8.cd pTest
9. sudo ./test 2
10. sudo ./test 100

PROOF OF SUCCESS:

- SEE IMAGE “Success”
