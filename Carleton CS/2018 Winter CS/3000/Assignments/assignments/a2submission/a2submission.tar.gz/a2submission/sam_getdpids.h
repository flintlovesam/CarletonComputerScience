/* Exercise 02 */
#ifndef SAM_TIME_H
#define SAM_TIME_H
int sam_getdpids(pid_t top, pid_t dpids[], int len)
#endif /* SAM_TIME_H */
